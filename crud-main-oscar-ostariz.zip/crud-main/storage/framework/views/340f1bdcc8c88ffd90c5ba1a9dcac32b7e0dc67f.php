<?php $__env->startSection("titulo"); ?>
    <h2>Dar de alta nuevo alumno</h2>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("opciones"); ?>
    <a href="<?php echo e(route('alumno.index')); ?>" class="btn btn-success mb-2">Volver al listado</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("contenido"); ?>
    <form action="<?php echo e(route('alumno.update',[$alumno])); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <?php echo method_field("PUT"); ?>
        <div class="form-group">
            <label for="nombre">Nombre</label>
            <input type="text" class="form-control" value="<?php echo e($alumno->nombre); ?>" name="nombre" placeholder="Inserta nombre">

            <label for="dni">DNI</label>
            <input type="text" class="form-control" placeholder="DNI" value="<?php echo e($alumno->dni); ?>"name ="dni">
        </div>
        <div class="form-group form-check">
            <label for="nombre">Dirección </label>
            <input type="text" class="form-control" placeholder="Dirección" value="<?php echo e($alumno->direccion); ?>"name="direccion">

            <label for="telefono">Teléfono</label>
            <input type="text" class="form-control" placeholder="Teléfono" value="<?php echo e($alumno->telefono); ?>"name="telefono">

        </div>
        <button type="submit" class="btn btn-primary">Guardar</button>
    </form>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make("alumno.layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/crud-main/resources/views/alumno/edit.blade.php ENDPATH**/ ?>