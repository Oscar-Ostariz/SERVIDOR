<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Gestión de alumnos</title>
    <link rel="stylesheet" href="{{asset ('./css/app.css')}}">

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
          integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

    <scrip src="{{asset('js/app.js')}}"></scrip>

</head>
<body>

<div class="container" class="col-lg-3 col-md-4 col-sm-6">

    <div class="row" class="col-lg-3 col-md-4 col-sm-6">
        <h1 class="alert-primary align-items-center p-3 m-5">Gestión de alumnos </h1>
    </div>

    <div class="row" class="col-lg-3 col-md-4 col-sm-6">
        @yield("titulo")
    </div>

    <div class="row" class="col-lg-3 col-md-4 col-sm-6">
        @yield("mensaje")
    </div>

    <div class="row" class="col-lg-3 col-md-4 col-sm-6">
        @yield("opciones")
    </div>

    <div class="col" class="col-lg-3 col-md-4 col-sm-6">
        @yield("contenido")
    </div>

</div>

</body>
</html>
